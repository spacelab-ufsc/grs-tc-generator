create function get_satellite_command_stats(days_interval integer DEFAULT 30)
    returns TABLE(satellite_id integer, satellite_name character varying, satellite_code character varying, total_commands bigint, pending_commands bigint, sent_commands bigint, confirmed_commands bigint, failed_commands bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT 
        s.id AS satellite_id,
        s.name AS satellite_name,
        s.code AS satellite_code,
        COUNT(t.id)::BIGINT AS total_commands,
        SUM(CASE WHEN t.status = 'pending' THEN 1 ELSE 0 END)::BIGINT AS pending_commands,
        SUM(CASE WHEN t.status = 'sent' THEN 1 ELSE 0 END)::BIGINT AS sent_commands,
        SUM(CASE WHEN t.status = 'confirmed' THEN 1 ELSE 0 END)::BIGINT AS confirmed_commands,
        SUM(CASE WHEN t.status = 'failed' THEN 1 ELSE 0 END)::BIGINT AS failed_commands
    FROM 
        satellites s
        LEFT JOIN telecommands t ON s.id = t.satellite_id
    WHERE 
        t.created_at >= (CURRENT_DATE - (days_interval || ' days')::INTERVAL)
    GROUP BY 
        s.id, s.name, s.code
    ORDER BY 
        total_commands DESC;
END;
$$;

alter function get_satellite_command_stats(integer) owner to root;

