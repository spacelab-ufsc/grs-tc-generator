create view vw_recent_telecommands
            (id, satellite_name, satellite_code, operator_username, command_type, status, created_at, sent_at,
             confirmed_at) as
SELECT t.id,
       s.name     AS satellite_name,
       s.code     AS satellite_code,
       o.username AS operator_username,
       t.command_type,
       t.status,
       t.created_at,
       t.sent_at,
       t.confirmed_at
FROM telecommands t
         JOIN satellites s ON t.satellite_id = s.id
         JOIN operators o ON t.operator_id = o.id
ORDER BY t.created_at DESC
LIMIT 100;

alter table vw_recent_telecommands
    owner to root;

